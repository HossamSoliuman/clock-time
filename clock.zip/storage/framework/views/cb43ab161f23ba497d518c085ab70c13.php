<!-- Header -->
<div class="container-fluid text-white g-2 p-0 me-0">
    <style>
        .img-city {
            background-image: url(<?php echo e(asset('/')); ?><?php echo e($imageUrl ?? 'public/ImgHomePage/banner.svg'); ?>);
        }
    </style>

    <div class="img-city img-city-convert-country">
        <div class="overlay">
            <div
                class="d-flex h-100 align-items-center justify-content-center wow animate__animated animate__fadeInLeft">
                <div class="cityBanner w-100">
                    <h1>
                        <?php echo e($name_1); ?>

                        <?php if(isset($name_2)): ?>
                        <br>
                        <?php echo e($name_2); ?>

                        <?php endif; ?>
                    </h1>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end Header -->
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/headers/convertCountryHeader.blade.php ENDPATH**/ ?>