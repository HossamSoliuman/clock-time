<?php

namespace App\Filament\Resources\GmtResource\Pages;

use App\Filament\Resources\GmtResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGmt extends CreateRecord
{
    protected static string $resource = GmtResource::class;
}
