<p align="center"><a href="https://www.loadserv.com.eg/" target="_blank"><img src="https://www.loadserv.com.eg/usersfile/images/brand-logo.png" width="400" alt="Laravel Logo"></a></p>



## About Project Time-Zone 

Time-Zone is a web application using laravel framework and Live-wire

## DATABASE GEO IP LOCATIO : GeoLite2-Country.mmdb
copy this file at storage/app/GeoLite2-Country.mmdb to detect ip 

#   c l o c k - t i m e  
 