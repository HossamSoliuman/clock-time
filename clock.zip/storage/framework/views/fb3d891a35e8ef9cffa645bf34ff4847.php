<!-- Third row -->

<div class="container-fluid position-relative">


    <section class="similarCitiesSection">
        <div class="row justify-content-center text-center bg-light p-md-5">
            <?php if(isset($type) && $type == 'city'): ?>
                <h2 class="mb-4 wow animate__animated animate__fadeInUp" style="font-size:38px;"><?php echo e($name); ?> similar Cities Clocks</h2>
            <?php else: ?>
                <h2 class="mb-4 wow animate__animated animate__fadeInUp" style="font-size:38px;">
                    <?php echo e($name); ?> Major Cities Clocks
                </h2>
            <?php endif; ?>
            <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 mb-3 col-12">
                    <div class="border rounded-3 p-3 wow animate__animated animate__fadeIn animate__slow h-100">
                        <div class="d-flex justify-content-between">
                            <div class="">
                                <div class="text-start">
                                    <p class="h2">
                                        <a href="<?php echo e(url($city->slug)); ?>" title="<?php echo e($city->name); ?> time now"
                                            style="color: black"><?php echo e($city->name); ?></a>

                                    </p>
                                    <p class="m-0 secoundText"> <?php echo e($city->dayOfWeek); ?></p>
                                </div>
                            </div>
                            <div class="">
                                <div class="text-end">
                                    <p class="gmt2 m-0" style="font-family: 'Lexend'; font-size: 32px; color: red;">
                                        <span class="current-time-display"> <?php echo e($city->currentTime); ?></span>
                                        <span class="current-time2-display"><?php echo e($city->identify); ?></span>
                                    </p>
                                    <input type="hidden" class="current-time-seconds"
                                        data-time="<?php echo e($city->currentTimeWithSecond); ?>">

                                </div>
                            </div>
                        </div>

                    </div>
                    </a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const timeDisplays = document.querySelectorAll('.current-time-display');
        const timeSeconds = document.querySelectorAll('.current-time-seconds');
        timeDisplays.forEach((display, index) => {
            const timeElement = timeSeconds[index];
            let [hours, minutes, seconds] = timeElement.dataset.time.split(':').map(Number);

            function updateTime() {
                let newHours = 0;
                seconds++; // Increment seconds
                let formattedTime2 = ' AM'
                if (seconds >= 60) {
                    seconds = 0;
                    minutes++;
                }
                if (minutes >= 60) {
                    minutes = 0;
                    hours++;
                }
                if (hours >= 24) {
                    hours = 0;
                }
                timeElement.dataset.time =
                    `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
                if (hours >= 12) {
                    formattedTime2 = ' PM'
                }
                if (hours > 12) {
                    newHours = hours - 12;
                } else {
                    newHours = hours
                }
                if (seconds === 0) {
                    const formattedTime = newHours + ':' + String(minutes).padStart(2, '0');
                    display.textContent = formattedTime;
                    display.nextElementSibling.textContent = formattedTime2
                }
            }
            setInterval(updateTime, 1000);
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/time/sections/similarCity.blade.php ENDPATH**/ ?>