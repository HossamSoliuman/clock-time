<?php $__env->startSection('title', 'Find Country Time'); ?>
<?php $__env->startSection('description', 'Check the current time in any country with our accurate country time tool. Easily view local times, time zones, and time differences to stay informed and plan across borders effortlessly'); ?>
<?php $__env->startSection('keywords', 'world time, country time, current time in country, time in any country, country time converter, global time lookup, country clock, time by country, country timezone, time finder, local time in country, check time in country, country time zone, international country time, country time search, time in major countries, find time anywhere, world clock by country'); ?>
<?php $__env->startSection('url', urldecode(url()->current())); ?>
<?php $__env->startSection('ogImage', 'https://theclocktime.com/images/country-time.jpg'); ?>
<?php $__env->startSection('ogImageAlt', 'country time'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .MeetingSection {
            background: rgba(243, 244, 246, 1);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php
    $imageUrl = 'public/images/country-time.jpg'
?>
<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('front.headers.convertCountryHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('front.sections.countrySearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.sections.meeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clock\resources\views/front/TimePage/country-time.blade.php ENDPATH**/ ?>