<section class="clockSection py-5">
    <div class="container">
        <div class="text-center">
            <h2>
                World Major Cities Analog Clocks
            </h2>
        </div>
        <div class="img">
            <img loading="lazy" src="{{ asset('public/ImgHomePage/clock.png') }}" alt="clock">
        </div>
        <div class="text-center">
            <button class="btn btn-convert rounded-2 px-5">Get yours  customized</button>
        </div>
    </div>
</section>
