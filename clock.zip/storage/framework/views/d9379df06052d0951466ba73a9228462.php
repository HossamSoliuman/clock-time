<div class="w-100">
    <div class="img-city">
        <div class="overlay">
            <div class="d-flex h-100 align-items-center wow animate__animated animate__fadeInLeft">
                <div class="ms-md-5 ps-md-5 pt-md-5 mt-md-5 p-3">
                    <h1 class="text-white"    style="font-family:Bree Serif,serif">
                        world clock time now
                    </h1>
                    <p>
                        Theclocktime.com   unite moments across the globe
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/sections/homeHeader.blade.php ENDPATH**/ ?>