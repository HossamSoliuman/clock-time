<?php $__env->startSection('title', 'Convert Time Zone'); ?>
<?php $__env->startSection('description', 'Quickly and easily convert time between different time zones worldwide. Accurate, reliable, and user-friendly tool to help you manage time differences with ease'); ?>
<?php $__env->startSection('keywords', 'Convert Time Zone,Convert Time between Zone,Convert Time Zones,Converter for Time Zone,Time Zones calculator ,convert time timezone ,convert time difference,time zone calculator, time zone converter, time conversion tool, world time calculator, time difference calculator, timezone calculator, time zone conversion, UTC to local time, convert time zones, local time calculator, cross time zone calculator, global time converter, calculate time difference'); ?>
<?php $__env->startSection('url', urldecode(url()->current())); ?>
<?php $__env->startSection('ogImage', 'https://theclocktime.com/images/convert-timezone.jpg'); ?>
<?php $__env->startSection('ogImageAlt', 'Convert Time Zone'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .MeetingSection {
            background: rgba(243, 244, 246, 1);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php
    $imageUrl = 'public/images/convert-timezone.jpg';
?>
<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('front.headers.convertCountryHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.converts.convertAbbToTime', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    <?php echo $__env->make('front.sections.meeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function () {
            $('#abbTotz').on('submit', function (event) {
                event.preventDefault(); // Prevent the default form submission

                // Get form action URL and form data
                var form = $(this);
                var url = form.attr('action');
                var formData = form.serialize();

                $.ajax({
                    url: url,
                    method: 'GET',
                    data: {
                        abb: tagify.value[0].slug,
                        tz: tagify2.value[0].slug,
                    },
                    success: function (response) {
                        // Process the response and update the hidden section
                        // Assuming the response contains the time data to display
                        // For example, let's say response has 'country1', 'city1', 'time1', 'country2', 'city2', 'time2'

                        $('#abb').text(response.abb);
                        $('#abb_time').text(response.abb_time);


                        $('#tz').text(response.tz);
                        $('#tz_name').text(response.tz_name);


                        // Show the hidden div
                        $('.converterUTC').show();
                        tagify.removeAllTags();
                        tagify2.removeAllTags();

                        // $('.analog').show();

                    },
                    error: function (xhr, status, error) {
                        // Handle any errors here
                        console.error('AJAX error:', error);
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clock\resources\views/front/convert-page/convert-tz.blade.php ENDPATH**/ ?>