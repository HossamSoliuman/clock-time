<section class="mapSection">
    <div class="container py-5">
        <div class="text-center">
            <h2>
                Live World Clocks
            </h2>
        </div>
        <div class="text-center mt-4">
            <div class="img">
                <img loading="lazy" src="{{ asset('public/ImgHomePage/map.png') }}" alt="map">
            </div>
        </div>
    </div>
</section>
