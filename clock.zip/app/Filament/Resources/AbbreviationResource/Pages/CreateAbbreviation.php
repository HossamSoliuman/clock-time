<?php

namespace App\Filament\Resources\AbbreviationResource\Pages;

use App\Filament\Resources\AbbreviationResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAbbreviation extends CreateRecord
{
    protected static string $resource = AbbreviationResource::class;
}
