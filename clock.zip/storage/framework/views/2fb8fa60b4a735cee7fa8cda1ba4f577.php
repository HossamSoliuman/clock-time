
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>
<?php $__env->startSection('keywords', $keywords); ?>
<?php $__env->startSection('ogImage', asset('images/city-time.jpg')); ?>
<?php $__env->startSection('ogImageAlt', $title); ?>
<?php $__env->startSection('url', urldecode(url()->current())); ?>
<?php
    $imageUrl = 'public/images/city-time.jpg';
?>
<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('front.time.sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.time.sections.timezoneToGmtUtc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.time.sections.similarCity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.time.sections.citySearch', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.time.sections.convertCityToCity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    



    <?php echo $__env->make('front.sections.meeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            $('#cityTocity').on('submit', function(event) {
                event.preventDefault(); // Prevent the default form submission

                // Get form action URL and form data
                var form = $(this);
                var url = form.attr('action');
                var formData = form.serialize();

                $.ajax({
                    url: url,
                    method: 'GET',
                    data: {
                        city_1: tagify.value[0].slug,
                        city_2: tagify3.value[0].slug,
                    },
                    success: function(response) {

                        $('#city_1').text(response.city1);
                        $('.converterUTC .col-lg-5:first .second').text(response.time1);

                        $('#city_2').text(response.city2);

                        $('.converterUTC .col-lg-5:last .second').text(response.time2);
                        // Show the hidden div
                        $('.converterUTC').show();
                        tagify.removeAllTags();
                        tagify3.removeAllTags();

                    },
                    error: function(xhr, status, error) {
                        // Handle any errors here
                        console.error('AJAX error:', error);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clock\resources\views/front/time/city.blade.php ENDPATH**/ ?>