<div>
    <tr>
        <td class="Prayer">Fajr</td>
        <td class="time">{{ $dataPayer['Fajr'] }} </td>
    </tr>
    <tr>
        <td class="Prayer">Zohr</td>
        <td class="time">{{ $dataPayer['Dhuhr'] }}</td>
    </tr>
    <tr>
        <td class="Prayer">Asr</td>
        <td class="time">{{ $dataPayer['Asr'] }}</td>
    </tr>
    <tr>
        <td class="Prayer">Magreb</td>
        <td class="time">{{ $dataPayer['Maghrib'] }}</td>
    </tr>
    <tr>
        <td class="Prayer">Eisha</td>
        <td class="time">{{ $dataPayer['Isha'] }}</td>
    </tr>

</div>
