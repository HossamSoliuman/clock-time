<?php

namespace App\Http\Controllers;

use App\Traits\GetDate;

abstract class Controller
{
   
}
