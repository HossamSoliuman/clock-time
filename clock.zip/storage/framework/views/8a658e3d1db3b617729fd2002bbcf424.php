<!doctype html>
<html lang="en">

<?php echo $__env->make('front.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

<body>

<?php echo $__env->make('front.inc.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->yieldContent('container'); ?>


<?php echo $__env->make('front.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/inc/layout.blade.php ENDPATH**/ ?>