
<?php $__env->startSection('title', $title); ?>
<?php $__env->startSection('description', $description); ?>
<?php $__env->startSection('keywords', $keywords); ?>
<?php $__env->startSection('url', urldecode(url()->current())); ?>
<?php $__env->startSection('ogImage', $ogImage); ?>
<?php $__env->startSection('ogImageAlt', $ogImageAlt); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .MeetingSection {
            background: rgba(243, 244, 246, 1);
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('front.time.sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.time.sections.timezoneToGmtUtc', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.time.sections.convertBetweenTimezones', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('front.sections.meeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>
        $(document).ready(function() {
            $('#abbTotz').on('submit', function(event) {
                event.preventDefault();
                var form = $(this);
                var url = form.attr('action');
                var formData = form.serialize();

                $.ajax({
                    url: url,
                    method: 'GET',
                    data: {
                        abb: tagify.value[0].slug,
                        tz: tagify2.value[0].slug,
                    },
                    success: function(response) {
                        $('#abb').text(response.abb);
                        $('#abb_time').text(response.abb_time);


                        $('#tz').text(response.tz);
                        $('#tz_name').text(response.tz_name);
                        $('.converterUTC').show();

                    },
                    error: function(xhr, status, error) {
                        console.error('AJAX error:', error);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clock\resources\views/front/timezone.blade.php ENDPATH**/ ?>