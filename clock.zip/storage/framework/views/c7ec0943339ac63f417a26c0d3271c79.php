<section class="clockUTC">
    <div class="container">
        <div class="row analog justify-content-center py-5" style="display:none ">
            <div class="col-lg-6">
                <div class="text-center">
                    <h2 style="font-family: Lexend,serif;font-size: 34px" id="utc1">UTC+2 Time</h2>
                    <p style="font-family: Lexend,serif;font-size: 16px" id="gmt1">GMT +02:00</p>
                </div>
                <div class="img">
                    <a id="link1" href="">
                        <img loading="lazy" src="<?php echo e(asset('public/clockUTC.png')); ?>" alt="clockUTC">
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="text-center">
                    <h2 style="font-family: Lexend,serif;font-size: 34px" id="utc2">UTC+2 Time</h2>
                    <p style="font-family: Lexend,serif;font-size: 16px" id="gmt2">GMT +02:00</p>
                </div>
                <div class="img">
                    <a id="link2" href="">
                        <img loading="lazy" src="<?php echo e(asset('public/clockUTC.png')); ?>" alt="clockUTC">
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/sections/clockCountry.blade.php ENDPATH**/ ?>