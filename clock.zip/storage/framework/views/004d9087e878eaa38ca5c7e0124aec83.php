<?php $__env->startSection('title', 'Find City Time'); ?>
<?php $__env->startSection('description', 'Find the current time in any city worldwide with our easy-to-use city time tool. Instantly check local times, time zones, and explore time differences across cities for seamless planning '); ?>
<?php $__env->startSection('keywords', 'world time, city time, current time in city, time in any city, city time converter, global time lookup, city clock, time by city, city timezone, time finder, local time in city, check time in city, city time zone, international city time, city time search, time in major cities, find time anywhere, world clock by city'); ?>
<?php $__env->startSection('url', urldecode(url()->current())); ?>
<?php $__env->startSection('ogImage', 'https://theclocktime.com/images/city-time.jpg'); ?>
<?php $__env->startSection('ogImageAlt', 'City time'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .MeetingSection {
            background: rgba(243, 244, 246, 1);
        }
    </style>
<?php $__env->stopSection(); ?>
<?php
    $imageUrl = 'public/images/city-time.jpg'
 ?>
<?php $__env->startSection('container'); ?>

    <?php echo $__env->make('front.headers.convertCountryHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <?php echo $__env->make('front.sections.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('front.sections.meeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <script>
        $(document).ready(function() {
            $('#cityTocity').on('submit', function(event) {
                event.preventDefault();

                var form = $(this);
                var url = form.attr('action');
                var formData = form.serialize();

                $.ajax({
                    url: url,
                    method: 'GET',
                    data: formData,
                    success: function(response) {

                        $('#city_1').text(response.city1);
                        $('.converterUTC .col-lg-5:first .second').text(response.time1);

                        $('#city_2').text(response.city2);

                        $('.converterUTC .col-lg-5:last .second').text(response.time2);
                        // Show the hidden div
                        $('.converterUTC').show();

                    },
                    error: function(xhr, status, error) {
                        // Handle any errors here
                        console.error('AJAX error:', error);
                    }
                });
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.inc.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\clock\resources\views/front/TimePage/city-time.blade.php ENDPATH**/ ?>