<!-- Header -->
<div class="container-fluid text-white g-2 p-0 me-0" style="margin-bottom: 8px">
    <style>
        .img-city {
            background-image: url(<?php echo e(asset('/')); ?><?php echo e($imageUrl ?? 'public/ImgHomePage/banner.svg'); ?>);
        }
    </style>


    <div class="img-city img-city-gmt">
        <div class="overlay">
            <div
                class="d-flex h-100 align-items-center justify-content-center wow animate__animated animate__fadeInLeft">


                <div class="cityBanner w-100">
                    <?php if(Request::is('meeting-planner')): ?>
                        <h1 class="fs-3" style="color:rgba(144, 149, 161, 1) ">Meeting Planner</h1>
                    <?php endif; ?>
                    <div class="mb-5">
                        <p class='time <?php echo e(Request::is('meeting-planner') ? '' : 'mt-5'); ?>'>
                            <span id="timeDisplay"><?php echo e($date['timewithSeconds']); ?></span>
                            <span id="timeDisplayspan"><?php echo e(strtolower($date['identify'])); ?></span>
                        </p>
                    </div>
                    <?php if(!Request::is('meeting-planner')): ?>
                        <div class='d-block d-md-flex justify-content-center align-items-center w-75 m-auto'>
                            <h1 class='display-5 mt-3 head' style="font-size:44px; color: white">
                                <?php echo e($timezoneName); ?> Time Now </h1>
                        </div>
                    <?php endif; ?>
                    <div class='d-block d-md-flex justify-content-center align-items-center w-75 m-auto'>
                        <p class='display-5 mt-3' style="font-size:34px; color: white">
                            <?php echo e(strtoupper($date['formatted_date'])); ?>

                        </p>
                    </div>

                    <?php if(isset($type) && $type == 'city'): ?>
                        <h2 class="btn-convert rounded-2 fs-6 d-inline-block px-3 py-2" style="font-weight: 400">
                            Time now in

                            <?php echo e($timezoneName); ?>

                            - <a href="<?php echo e(url($country->slug)); ?>" style="color: white"><?php echo e($country->name); ?></a>
                            - <a href="<?php echo e(url($timezoneSlug)); ?>" style="color: white"><?php echo e($timezone); ?></a>
                            Time zone.
                        </h2>
                    <?php elseif(isset($type) && $type == 'country'): ?>
                        <h2 class="btn-convert rounded-2 fs-6 d-inline-block px-3 py-2" style="font-weight: 400">
                            Time now in
                            <?php echo e($timezoneName); ?>

                            Based on Capital
                            - <a href="<?php echo e(url($capital->slug)); ?>" style="color: white"><?php echo e($capital->name); ?></a>
                            - Time Zone
                            - <a href="<?php echo e(url($timezoneSlug)); ?>" style="color: white"><?php echo e($capital->timezone); ?></a>
                            .
                        </h2>
                    <?php elseif(isset($type) && $type == 'meeting-planner'): ?>
                        <h2 class="btn-convert rounded-2 fs-6 d-inline-block px-3 py-2" style="font-weight: 400">
                            Time now in
                            - <a href="<?php echo e(url($country->slug)); ?>" style="color: white"><?php echo e($country->name); ?></a>
                            Based on Capital
                            - <a href="<?php echo e(url($city->slug)); ?>" style="color: white"><?php echo e($city->name); ?></a>
                            - Time Zone
                            - <a href="<?php echo e(url($ianaTimezone->slug)); ?>"
                                style="color: white"><?php echo e($ianaTimezone->iana_timezone); ?></a>
                            .
                        </h2>
                    <?php else: ?>
                        <h2 class="btn-convert rounded-2 fs-6 d-inline-block px-3 py-2" style="font-weight: 400">
                            Time now in
                            (<?php echo e($timezoneName); ?>) Time zone.
                        </h2>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</div>
<!-- end Header -->
<script>
    // Retrieve the initial time from the HTML content
    const initialTime = document.getElementById('timeDisplay').textContent;
    let [hours, minutes, seconds] = initialTime.split(':').map(Number);

    function updateDisplay() {
        const formattedTime =
            `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        document.getElementById('timeDisplay').textContent = formattedTime;
    }

    function incrementTime() {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            minutes++;
            if (minutes >= 60) {
                minutes = 0;
                hours++;
                if (hours >= 24) hours = 0;
            }
        }
        updateDisplay();
    }

    // Initial display and start the counter
    updateDisplay();
    setInterval(incrementTime, 1000);
</script>
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/time/sections/header.blade.php ENDPATH**/ ?>