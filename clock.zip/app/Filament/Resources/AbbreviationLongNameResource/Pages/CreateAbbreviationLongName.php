<?php

namespace App\Filament\Resources\AbbreviationLongNameResource\Pages;

use App\Filament\Resources\AbbreviationLongNameResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAbbreviationLongName extends CreateRecord
{
    protected static string $resource = AbbreviationLongNameResource::class;
}
