<!-- Cities -->
<!--<?php echo e(asset('images/theclocktime-logo.png')); ?>-->
<section class="citiesSection" style="margin-top: 10px">
    <div class="container-fluid">
        <div class="text-center">
            <h2 class=" wow animate__animated animate__fadeInUp">Time in World Major Cities </h2>
        </div>
        <div class="row justify-content-center text-center p-md-3">
            <?php $__currentLoopData = $data['capital']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-6 col-12">
                    <?php
                        $cityName = $city->name;
                        $currentTimeWithoutSecond = $city->currentTime;
                        $currentTimeWithSecond = $city->currentTimeWithSecond;
                        $identify = $city->identify;

                    ?>

                    <div>
                        <div
                            class="border rounded-3 px-3 text-lg-end mb-3 d-flex flex-column wow animate__animated animate__fadeIn animate__slow h-100">
                            <div class="row justify-content-between h-100">
                                <div class="col-lg-6 col-7">
                                    <div class="text-start h-100">
                                        <div class="d-flex flex-column justify-content-between h-100">
                                            <div>

                                                <a href="<?php echo e(url($city->slug)); ?>" title="<?php echo e($city->name); ?> time now">
                                                    <p class="mb-0 citiesSectionp" style="margin-top:11px;">
                                                        
                                                        <?php echo e($city->name); ?>

                                                    </p>
                                                </a>
                                                <!-- HTML content for each city block -->
                                                <input type="hidden" id="timeWith<?php echo e($city->slug); ?>"
                                                    class="citiesSectionTimeSecond"
                                                    value="<?php echo e($currentTimeWithSecond); ?>">
                                                <p class="citiesSectionh2 mb-0" style="font-family:'Lexend', serif;"
                                                    id="timeWithout<?php echo e($city->slug); ?>"><span
                                                        class="citiesSectionTime"><?php echo e($currentTimeWithoutSecond); ?>

                                                    </span><span><?php echo e($identify); ?></span> </p>
                                            </div>
                                            <a href="<?php echo e(url($city->countrySlug)); ?>"
                                                title="<?php echo e($city->country); ?> time now">
                                                <p style="color: #9095A1;  font-family: Lexend,serif; font-size: 18px"
                                                    class="p-0 mb-3"> <?php echo e($city->country); ?></p>
                                            </a>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-5">

                                    <div class="text-md-end py-3 h-100">
                                        <?php
                                            $imageUrl =
                                                strlen($city->country) > 0
                                                    ? 'public/country/' . $city->country
                                                    : 'public/ImgHomePage/city.svg';
                                        ?>
                                        <img loading="lazy" src="<?php echo e($city->image); ?>" class="capitalImages"
                                            alt="<?php echo e($city->name); ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<!-- Cities end -->
<?php /**PATH C:\xampp\htdocs\clock\resources\views/front/sections/city.blade.php ENDPATH**/ ?>